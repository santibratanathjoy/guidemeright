from django.contrib import admin

from authentication.models import User

# Register your models here.
admin.site.register(User)
